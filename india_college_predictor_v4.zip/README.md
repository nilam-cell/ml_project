# India College Admission Predictor — V4

V4 is the real-data architecture for:

- Gujarat ACPC
- JoSAA IIT / NIT / IIIT / GFTI
- CSAB Special

## Data policy

The bundled Gujarat file is real ACPC 2024 DDCET institute-wise cutoff data.
JoSAA/CSAB are **not fabricated** in this ZIP. V4 includes download/ingestion scripts that fetch real historical datasets on an internet-enabled machine, then normalizes them into one schema while keeping admission systems separate.

JoSAA's official archive exposes previous-year opening/closing ranks and identifies IITs, NITs, IIITs and other GFTIs. CSAB separately publishes Special Round opening/closing ranks. Gujarat ACPC maintains its own engineering cutoff/archive system.

## Quick start

### 1. Install

```bash
pip install -r requirements.txt
playwright install chromium
```

### 2. Download real JoSAA + CSAB datasets

```bash
python scripts/download_real_data.py
```

This downloads:
- JoSAA historical CSVs from a public mirror whose README documents that the data were exported from JoSAA. The mirror covers 2016–2024 and all IIT/NIT/IIIT/GFTI seat buckets.
- CSAB historical CSV where available from a public research implementation that documents its CSAB data as 2021–2026.

The scripts retain provenance and do not silently label mirrors as official files.

### 3. Normalize and build

```bash
python scripts/build_dataset_v4.py
```

Output:
`data/processed/college_cutoffs_v4.csv`

### 4. Train

```bash
python scripts/train_v4.py
```

### 5. Run app

```bash
streamlit run app/streamlit_app.py
```

## Important modeling rule

JoSAA/CSAB rank systems and Gujarat ACPC/DDCET/GUJCET systems are kept separate. V4 never treats a JEE rank as directly comparable to a GUJCET/DDCET merit rank.

The model forecasts a closing-rank distribution only where enough historical years exist. A single historical year is shown as historical fit, not as a fake ML probability.

## Official source registry

See `docs/official_sources.csv`.

## Current bundled data

The ZIP includes real Gujarat ACPC DDCET 2024 institute-wise data as a seed. JoSAA and CSAB are downloaded by the ingestion script because their live archive interfaces/datasets are dynamic and should not be represented by hand-created rows.
