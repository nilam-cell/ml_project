import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import streamlit as st
import pandas as pd
from src.model_v4 import forecast_next, slot_history

st.set_page_config(page_title='India College Predictor V4',layout='wide')
DATA=ROOT/'data/processed/college_cutoffs_v4.csv'
if not DATA.exists():
    st.error('Dataset not built. Run: python scripts/download_real_data.py && python scripts/build_dataset_v4.py')
    st.stop()
df=pd.read_csv(DATA)

st.title('India College Admission Predictor — V4')
st.caption('Real-data architecture: Gujarat ACPC + JoSAA IIT/NIT/IIIT/GFTI + CSAB. Admission systems remain separate.')

sysname=st.sidebar.selectbox('Admission system',sorted(df.admission_system.unique()))
d=df[df.admission_system==sysname].copy()
rank=st.sidebar.number_input('Your rank / merit rank',1,10_000_000,10000,1)

institute=st.sidebar.selectbox('Institute',['Any']+sorted(d.institute.dropna().unique()))
if institute!='Any': d=d[d.institute==institute]
program=st.sidebar.selectbox('Program',['Any']+sorted(d.program.dropna().unique()))
if program!='Any': d=d[d.program==program]
category=st.sidebar.selectbox('Category',['Any']+sorted(d.category.dropna().astype(str).unique()))
if category!='Any': d=d[d.category.astype(str)==category]
quota=st.sidebar.selectbox('Quota',['Any']+sorted(d.quota.dropna().astype(str).unique()))
if quota!='Any': d=d[d.quota.astype(str)==quota]
gender=st.sidebar.selectbox('Gender',['Any']+sorted(d.gender.dropna().astype(str).unique())) if 'gender' in d else 'Any'
if gender!='Any': d=d[d.gender.astype(str)==gender]

d['last_rank']=pd.to_numeric(d.last_rank,errors='coerce')
d=d.dropna(subset=['last_rank'])
d['rank_clears_cutoff']=rank<=d.last_rank

st.subheader('Historical cutoff matches')
st.dataframe(d.sort_values(['year','last_rank'],ascending=[False,True]).head(500),use_container_width=True,hide_index=True)

if institute!='Any' and program!='Any' and category!='Any' and quota!='Any':
    hist=slot_history(df,institute,program,quota,category,None if gender=='Any' else gender)
    st.subheader('Slot history')
    st.dataframe(hist[['year','round','last_rank','source']].sort_values(['year','round'],ascending=False),use_container_width=True,hide_index=True)
    pred=forecast_next(df,institute,program,quota,category,None if gender=='Any' else gender)
    if pred:
        st.subheader('Next-year closing-rank forecast')
        a,b,c,dcol=st.columns(4)
        a.metric('Forecast',f"{pred['forecast']:,.0f}")
        b.metric('P10',f"{pred['p10']:,.0f}")
        c.metric('Median',f"{pred['p50']:,.0f}")
        dcol.metric('P90',f"{pred['p90']:,.0f}")
        if rank<=pred['p10']: st.success('Historical-model signal: relatively favorable')
        elif rank<=pred['p90']: st.warning('Historical-model signal: uncertain / competitive')
        else: st.error('Historical-model signal: relatively difficult')
        st.caption(f'Forecast based on {pred["years"]} historical year-level observations. This is not a guaranteed admission probability.')
    else:
        st.info('At least 3 comparable historical years are needed for the slot forecast.')

st.subheader('Summary')
match=int(d.rank_clears_cutoff.sum())
st.metric('Rows where your rank clears the recorded closing rank',match)
st.download_button('Export filtered CSV',d.to_csv(index=False).encode(),file_name='v4_filtered_cutoffs.csv',mime='text/csv')
