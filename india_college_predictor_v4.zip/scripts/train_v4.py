from pathlib import Path
import pandas as pd, joblib
from src.model_v4 import evaluate_holdout
ROOT=Path(__file__).resolve().parents[1]
df=pd.read_csv(ROOT/'data/processed/college_cutoffs_v4.csv')
res=evaluate_holdout(df)
print('Backtest:',res)
print('Training note: V4 uses per-slot historical forecasting in the app; no synthetic admission labels are generated.')
