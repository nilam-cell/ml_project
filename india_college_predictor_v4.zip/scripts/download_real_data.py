from pathlib import Path
import requests, json, re

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'data/raw'
RAW.mkdir(parents=True,exist_ok=True)

HEAD={'User-Agent':'india-college-predictor-v4/1.0'}

def get(url):
    r=requests.get(url,headers=HEAD,timeout=60)
    r.raise_for_status(); return r

def download(url,path):
    print('GET',url)
    r=get(url)
    path.write_bytes(r.content)
    print('  ->',path, len(r.content),'bytes')

# JoSAA mirror: the repository documents that its CSVs were exported from JoSAA.
# It contains 2016-2024, IIT/NIT/IIIT/GFTI, all categories/rounds listed in its README.
api='https://api.github.com/repos/PardhavMaradani/josaa-sql-interface/contents/csv'
r=get(api)
items=r.json()
count=0
for item in items:
    name=item.get('name','')
    if not name.lower().endswith('.csv'):
        continue
    if not re.match(r'josaa-\d{4}-r\d+-all\.csv$',name):
        continue
    out=RAW/'josaa'/name
    out.parent.mkdir(exist_ok=True)
    if out.exists() and out.stat().st_size>0:
        continue
    download(item['download_url'],out)
    count+=1
print('JoSAA files downloaded:',count)

# CSAB mirror/research implementation. Its repository README documents CSAB 2021-2026 data.
csab_url='https://raw.githubusercontent.com/Harith-Y/JoSAA-CSAB-Closing-Rank-Predictor/main/data/csab_ranks.csv'
out=RAW/'csab_ranks.csv'
if not out.exists() or out.stat().st_size==0:
    try:
        download(csab_url,out)
    except Exception as e:
        print('CSAB download failed:',e)
        print('You can manually place csab_ranks.csv in data/raw/.')

manifest={
  'joSAA_mirror':'PardhavMaradani/josaa-sql-interface',
  'csab_mirror':'Harith-Y/JoSAA-CSAB-Closing-Rank-Predictor',
  'official_sources':'docs/official_sources.csv'
}
(RAW/'download_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
