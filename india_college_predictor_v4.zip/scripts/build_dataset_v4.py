from pathlib import Path
import pandas as pd, json, re

ROOT=Path(__file__).resolve().parents[1]
RAW=ROOT/'data/raw'; OUT=ROOT/'data/processed/college_cutoffs_v4.csv'
OUT.parent.mkdir(parents=True,exist_ok=True)
frames=[]

def clean_num(s):
    return pd.to_numeric(s.astype(str).str.replace(',','',regex=False).str.extract(r'(\d+(?:\.\d+)?)')[0],errors='coerce')

# Existing normalized ACPC seed.
for f in RAW.glob('*.csv'):
    if f.name in {'college_cutoffs_v4.csv'}: continue
    try: d=pd.read_csv(f)
    except Exception: continue
    if {'year','institute','program','last_rank'}.issubset(d.columns):
        frames.append(d)

# JoSAA exported CSVs: columns are normalized to the V4 schema.
for f in (RAW/'josaa').glob('josaa-*-r*-all.csv') if (RAW/'josaa').exists() else []:
    try: d=pd.read_csv(f)
    except Exception as e:
        print('skip',f,e); continue
    cols={c.lower().strip():c for c in d.columns}
    def pick(*names):
        for n in names:
            if n in cols: return cols[n]
        return None
    y=pick('year'); rnd=pick('round'); typ=pick('type'); inst=pick('institute'); prog=pick('program'); quota=pick('quota'); cat=pick('category'); gender=pick('gender'); op=pick('orank','opening rank','opening_rank'); cr=pick('crank','closing rank','closing_rank')
    if not all([y,inst,prog,op,cr]):
        print('skip unrecognized',f); continue
    x=pd.DataFrame({
      'year':d[y], 'round':d[rnd] if rnd else None,
      'admission_system':'JoSAA', 'institute_type':d[typ] if typ else 'Unknown',
      'institute':d[inst], 'program':d[prog], 'quota':d[quota] if quota else 'AI',
      'category':d[cat] if cat else 'OPEN', 'gender':d[gender] if gender else 'Gender-Neutral',
      'first_rank':d[op], 'last_rank':d[cr],
      'source':'JoSAA-derived public export mirror; verify against official JoSAA archive'
    })
    frames.append(x)

# CSAB dataset. Handle common field names.
f=RAW/'csab_ranks.csv'
if f.exists():
    d=pd.read_csv(f)
    c={c.lower().strip():c for c in d.columns}
    def p(*ns):
        for n in ns:
            if n in c:return c[n]
    y=p('year'); inst=p('institute','college'); prog=p('program','branch'); op=p('orank','opening_rank','opening rank'); cr=p('crank','closing_rank','closing rank'); quota=p('quota'); cat=p('category','seat_type'); gender=p('gender'); rnd=p('round')
    if all([y,inst,prog,cr]):
        x=pd.DataFrame({'year':d[y],'round':d[rnd] if rnd else None,'admission_system':'CSAB','institute_type':'NIT+','institute':d[inst],'program':d[prog],'quota':d[quota] if quota else 'AI','category':d[cat] if cat else 'OPEN','gender':d[gender] if gender else 'Gender-Neutral','first_rank':d[op] if op else None,'last_rank':d[cr],'source':'CSAB-derived public dataset; verify against official CSAB archive'})
        frames.append(x)

if not frames: raise SystemExit('No real/normalized datasets found. Run download_real_data.py first.')
outdf=pd.concat(frames,ignore_index=True)
for c in ['year','round','first_rank','last_rank','first_marks','last_marks']:
    if c in outdf: outdf[c]=clean_num(outdf[c])
outdf['year']=outdf['year'].astype('Int64')
outdf['admission_system']=outdf['admission_system'].fillna('Unknown')
outdf=outdf.dropna(subset=['year','institute','program','last_rank']).drop_duplicates()
outdf.to_csv(OUT,index=False)
print('Wrote',len(outdf),'rows ->',OUT)
print(outdf.groupby('admission_system').size())
print('years:', sorted(outdf.year.dropna().astype(int).unique()))
