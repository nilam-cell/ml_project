import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error

def slot_history(df, institute, program, quota, category, gender=None):
    x=df[(df.institute==institute)&(df.program==program)&(df.quota==quota)&(df.category==category)].copy()
    if gender is not None and 'gender' in x.columns:
        x=x[x.gender==gender]
    return x.sort_values(['year','round'])

def forecast_next(df, institute, program, quota, category, gender=None):
    h=slot_history(df,institute,program,quota,category,gender)
    if h.year.nunique()<3: return None
    # Use final round per year so the target is comparable across years.
    h=h.sort_values(['year','round']).groupby('year',as_index=False).tail(1)
    y=pd.to_numeric(h.last_rank,errors='coerce').dropna()
    if len(y)<3:return None
    years=pd.to_numeric(h.loc[y.index,'year'])
    X=pd.DataFrame({'year':years,'year2':years**2})
    model=HistGradientBoostingRegressor(max_iter=250,l2_regularization=1.0,random_state=42)
    model.fit(X,y)
    target=int(years.max()+1)
    pred=float(model.predict(pd.DataFrame({'year':[target],'year2':[target**2]}))[0])
    resid=y-model.predict(X)
    return {'forecast':max(1,pred),'p10':max(1,pred+np.quantile(resid,.10)),'p50':max(1,pred+np.quantile(resid,.50)),'p90':max(1,pred+np.quantile(resid,.90)),'years':int(len(y))}

def evaluate_holdout(df):
    rows=[]
    for key,g in df.groupby(['admission_system','institute','program','quota','category'],dropna=False):
        if g.year.nunique()<4: continue
        years=sorted(g.year.dropna().unique())
        val=years[-1]
        train=g[g.year<val]
        pred=forecast_next(train,*key[1:]) if len(train) else None
        if pred: rows.append({'system':key[0],'institute':key[1],'program':key[2],'actual_year':val,'predicted':pred['forecast'],'actual':float(g[g.year==val].last_rank.median())})
    if not rows:return None
    r=pd.DataFrame(rows)
    return {'rows':len(r),'mae':mean_absolute_error(r.actual,r.predicted)}
