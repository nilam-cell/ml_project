# India College Admission Predictor — V5 (10-Year Data)

## What changed from V4

V5 is the 10-year historical-data version of the college predictor.

- **JoSAA:** 2016–2025 (10 complete years)
- **CSAB:** 2021–2025 when the public dataset is available
- **ACPC DDCET:** official 2024 seed bundled from the ACPC archive
- Time-based backtesting now reports **MAE, RMSE and R²**.
- The app explains rank comparisons as historical signals, not guarantees.
- P10/P50/P90 are forecast-rank ranges, not admission probabilities.

## Data provenance

The JoSAA downloader uses the public `Harith-Y/JoSAA-CSAB-Closing-Rank-Predictor` dataset, whose README documents JoSAA data for 2016–2026. This project deliberately filters that dataset to **2016–2025** to create a clean ten-year historical window. The official JoSAA archive remains the authoritative source for verification:

- https://josaa.admissions.nic.in/applicant/seatmatrix/openingclosingrankarchieve.aspx
- https://josaa.nic.in/or-cr/

The public dataset is an ingestion convenience and is not relabeled as an official JoSAA file.

ACPC source:
- https://gujacpc.admissions.nic.in/archive/

CSAB source:
- https://csab.nic.in/archive/

## Important modeling rule

JEE/JoSAA ranks, CSAB ranks and Gujarat ACPC DDCET/GUJCET merit systems are **not directly comparable**. The app keeps admission systems separate.

## Run on Windows

Install Python 3.10+ and run:

```bat
python -m pip install -r requirements.txt
python scripts/download_real_data.py
python scripts/build_dataset_v4.py
python scripts/train_v4.py
streamlit run app/streamlit_app.py
```

The first data download requires internet access and can be large because the JoSAA source contains hundreds of thousands of historical rows.

## Model

The current per-slot forecasting model is `HistGradientBoostingRegressor` using year and year². A slot is defined by admission system, institute, program, quota, category and, when available, gender.

For each slot, the model uses the final available round for each year. Forecasts are produced only when at least three comparable historical years exist.

## Evaluation

`train_v4.py` performs an expanding, time-based backtest. It predicts later historical years using earlier years only. It reports:

- **MAE** — average absolute rank error
- **RMSE** — penalizes larger errors more strongly
- **R²** — variance explained by the predictions relative to a constant baseline

R² can be negative. That is not a software error; it means the model performed worse than a simple baseline on that test set.

## Limitations

This is an academic ML project, not an admission guarantee. Seat availability, counselling round, category rules, quota, gender pool, preferences, and year-to-year changes can materially affect actual admission.
