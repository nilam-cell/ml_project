Bundled: acpc_ddcet_2024_official_seed.csv = real Gujarat ACPC 2024 DDCET institute-wise cutoff seed.
Run scripts/download_real_data.py to obtain JoSAA/CSAB historical files on an internet-enabled machine.
