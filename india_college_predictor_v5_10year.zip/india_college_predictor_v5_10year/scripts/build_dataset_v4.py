from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data' / 'raw'
OUT = ROOT / 'data' / 'processed'
OUT.mkdir(parents=True, exist_ok=True)


def clean_num(s):
    return pd.to_numeric(s.astype(str).str.replace(',', '', regex=False).str.extract(r'(\d+(?:\.\d+)?)')[0], errors='coerce')

frames = []

# Bundled official ACPC seed remains available; it is a separate admission system.
acpc = RAW / 'acpc_ddcet_2024_official_seed.csv'
if acpc.exists():
    a = pd.read_csv(acpc)
    frames.append(a)

# Ten-year JoSAA data (2016-2025).
j = RAW / 'josaa_ranks_2016_2025.csv'
if j.exists():
    x = pd.read_csv(j, low_memory=False)
    cols = {c.lower().strip(): c for c in x.columns}
    def pick(*names):
        for n in names:
            if n in cols:
                return cols[n]
        return None
    year = pick('year')
    institute = pick('institute')
    program = pick('program', 'academic program name')
    quota = pick('quota')
    category = pick('category')
    gender = pick('gender', 'seat pool')
    orank = pick('orank', 'opening rank')
    crank = pick('crank', 'closing rank')
    rnd = pick('round', 'round no')
    typ = pick('type', 'institute type')
    required = [year, institute, program, quota, category, gender, orank, crank, rnd]
    if any(v is None for v in required):
        raise ValueError(f'JoSAA columns not recognized. Found: {list(x.columns)}')
    j2 = pd.DataFrame({
        'year': pd.to_numeric(x[year], errors='coerce'),
        'admission_system': 'JoSAA',
        'institute': x[institute].astype(str).str.strip(),
        'program': x[program].astype(str).str.strip(),
        'quota': x[quota].astype(str).str.strip(),
        'category': x[category].astype(str).str.strip(),
        'gender': x[gender].astype(str).str.strip(),
        'round': x[rnd].astype(str).str.extract(r'(\d+)')[0].astype(float),
        'first_rank': clean_num(x[orank]),
        'last_rank': clean_num(x[crank]),
        'source': 'JoSAA public historical dataset mirror',
        'source_url': 'https://josaa.admissions.nic.in/applicant/seatmatrix/openingclosingrankarchieve.aspx',
        'data_type': 'historical_2016_2025'
    })
    if typ:
        j2['institute_type'] = x[typ].astype(str).str.strip()
    j2 = j2[j2.year.between(2016, 2025)]
    frames.append(j2)

# CSAB data, if downloaded.
c = RAW / 'csab_ranks.csv'
if c.exists():
    try:
        z = pd.read_csv(c, low_memory=False)
        cols = {q.lower().strip(): q for q in z.columns}
        def cpick(*names):
            for n in names:
                if n in cols:
                    return cols[n]
            return None
        year, institute, program = cpick('year'), cpick('institute'), cpick('program', 'academic program name')
        quota, category, gender = cpick('quota'), cpick('category'), cpick('gender', 'seat pool')
        crank = cpick('crank', 'closing rank', 'closing_rank')
        orank = cpick('orank', 'opening rank', 'opening_rank')
        rnd = cpick('round', 'round no')
        if all(v is not None for v in [year, institute, program, quota, category, gender, crank, rnd]):
            c2 = pd.DataFrame({
                'year': pd.to_numeric(z[year], errors='coerce'),
                'admission_system': 'CSAB',
                'institute': z[institute].astype(str).str.strip(),
                'program': z[program].astype(str).str.strip(),
                'quota': z[quota].astype(str).str.strip(),
                'category': z[category].astype(str).str.strip(),
                'gender': z[gender].astype(str).str.strip(),
                'round': z[rnd].astype(str).str.extract(r'(\d+)')[0].astype(float),
                'first_rank': clean_num(z[orank]) if orank else None,
                'last_rank': clean_num(z[crank]),
                'source': 'CSAB public historical dataset mirror',
                'source_url': 'https://csab.nic.in/archive/',
                'data_type': 'historical_2021_2025'
            })
            frames.append(c2)
    except Exception as e:
        print('CSAB normalization skipped:', e)

if not frames:
    raise FileNotFoundError('No raw datasets found. Run scripts/download_real_data.py first.')

all_df = pd.concat(frames, ignore_index=True, sort=False)
for col in ['first_rank', 'last_rank', 'year', 'round']:
    all_df[col] = pd.to_numeric(all_df[col], errors='coerce')
all_df = all_df.dropna(subset=['year', 'last_rank'])
all_df['year'] = all_df['year'].astype(int)
all_df.to_csv(OUT / 'college_cutoffs_v4.csv', index=False)
print('Wrote', len(all_df), 'rows to', OUT / 'college_cutoffs_v4.csv')
print(all_df.groupby('admission_system').agg(rows=('year','size'), min_year=('year','min'), max_year=('year','max')).to_string())
