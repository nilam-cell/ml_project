from pathlib import Path
import json
import requests
import pandas as pd
from io import StringIO

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data' / 'raw'
RAW.mkdir(parents=True, exist_ok=True)

HEAD = {'User-Agent': 'india-college-predictor-v5/1.0'}

JOSAA_URL = 'https://raw.githubusercontent.com/Harith-Y/JoSAA-CSAB-Closing-Rank-Predictor/main/data/josaa_ranks.csv'
CSAB_URL = 'https://raw.githubusercontent.com/Harith-Y/JoSAA-CSAB-Closing-Rank-Predictor/main/data/csab_ranks.csv'

# Ten complete historical JoSAA years: 2016-2025.
START_YEAR, END_YEAR = 2016, 2025


def download(url, path):
    print('GET', url)
    with requests.get(url, headers=HEAD, timeout=180, stream=True) as r:
        r.raise_for_status()
        with path.open('wb') as f:
            for chunk in r.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    f.write(chunk)
    print('  ->', path, path.stat().st_size, 'bytes')


# The public research mirror contains JoSAA 2016-2026 data.
# We retain exactly 2016-2025 so the project has a clean 10-year historical window.
josaa_all = RAW / 'josaa_ranks_2016_2026.csv'
josaa_10y = RAW / 'josaa_ranks_2016_2025.csv'
if not josaa_all.exists() or josaa_all.stat().st_size == 0:
    download(JOSAA_URL, josaa_all)

print('Filtering JoSAA to 2016-2025...')
chunks = []
for chunk in pd.read_csv(josaa_all, chunksize=100_000, low_memory=False):
    year_col = 'year' if 'year' in chunk.columns else 'Year'
    chunk[year_col] = pd.to_numeric(chunk[year_col], errors='coerce')
    chunk = chunk[chunk[year_col].between(START_YEAR, END_YEAR)]
    if not chunk.empty:
        chunks.append(chunk)
if not chunks:
    raise RuntimeError('No JoSAA rows found for 2016-2025.')
pd.concat(chunks, ignore_index=True).to_csv(josaa_10y, index=False)
print('  ->', josaa_10y, josaa_10y.stat().st_size, 'bytes')

# CSAB is kept as an additional admission system. The current public dataset covers 2021-2025.
csab = RAW / 'csab_ranks.csv'
if not csab.exists() or csab.stat().st_size == 0:
    try:
        download(CSAB_URL, csab)
    except Exception as e:
        print('CSAB download failed:', e)
        print('JoSAA 10-year dataset can still be built without CSAB.')

manifest = {
    'project_window': '2016-2025 (10 complete years)',
    'josaa_dataset': 'Harith-Y/JoSAA-CSAB-Closing-Rank-Predictor/data/josaa_ranks.csv',
    'josaa_source_note': 'Public research mirror; README documents 2016-2026 JoSAA data. Project filters to 2016-2025.',
    'csab_dataset': 'Harith-Y/JoSAA-CSAB-Closing-Rank-Predictor/data/csab_ranks.csv',
    'official_josaa_archive': 'https://josaa.admissions.nic.in/applicant/seatmatrix/openingclosingrankarchieve.aspx',
    'official_josaa_orcr': 'https://josaa.nic.in/or-cr/'
}
(RAW / 'download_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
