from pathlib import Path
import pandas as pd
from src.model_v4 import evaluate_holdout

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data' / 'processed' / 'college_cutoffs_v4.csv'
OUT = ROOT / 'data' / 'processed'

df = pd.read_csv(DATA)
result = evaluate_holdout(df, min_train_years=4, validation_years=3)
if result is None:
    print('No eligible multi-year slots for backtesting.')
else:
    print(f"Backtest rows: {result['rows']}")
    print(f"MAE:  {result['mae']:.2f}")
    print(f"RMSE: {result['rmse']:.2f}")
    print(f"R2:   {result['r2']:.4f}")
    result['predictions'].to_csv(OUT / 'backtest_predictions_v4.csv', index=False)
    print('Saved backtest_predictions_v4.csv')
