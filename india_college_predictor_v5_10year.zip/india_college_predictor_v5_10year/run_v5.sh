#!/usr/bin/env bash
set -e
python3 -m pip install -r requirements.txt
python3 scripts/download_real_data.py
python3 scripts/build_dataset_v4.py
python3 scripts/train_v4.py
streamlit run app/streamlit_app.py
