import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def slot_history(df, institute, program, quota, category, gender=None):
    x = df[(df.institute == institute) & (df.program == program) &
           (df.quota == quota) & (df.category == category)].copy()
    if gender is not None and 'gender' in x.columns:
        x = x[x.gender == gender]
    return x.sort_values(['year', 'round'])


def _final_years(h):
    h = h.copy()
    h['last_rank'] = pd.to_numeric(h['last_rank'], errors='coerce')
    h['year'] = pd.to_numeric(h['year'], errors='coerce')
    h = h.dropna(subset=['year', 'last_rank']).sort_values(['year', 'round'])
    return h.groupby('year', as_index=False).tail(1).sort_values('year')


def forecast_next(df, institute, program, quota, category, gender=None):
    h = _final_years(slot_history(df, institute, program, quota, category, gender))
    if h.year.nunique() < 3:
        return None
    y = h['last_rank'].to_numpy(dtype=float)
    years = h['year'].to_numpy(dtype=float)
    X = pd.DataFrame({'year': years, 'year2': years ** 2})
    model = HistGradientBoostingRegressor(max_iter=250, l2_regularization=1.0, random_state=42)
    model.fit(X, y)
    target = int(years.max() + 1)
    pred = float(model.predict(pd.DataFrame({'year': [target], 'year2': [target ** 2]}))[0])
    resid = y - model.predict(X)
    return {
        'forecast': max(1, pred),
        'p10': max(1, pred + np.quantile(resid, .10)),
        'p50': max(1, pred + np.quantile(resid, .50)),
        'p90': max(1, pred + np.quantile(resid, .90)),
        'years': int(len(y)),
        'last_year': int(years.max())
    }


def evaluate_holdout(df, min_train_years=4, validation_years=3):
    rows = []
    keys = ['admission_system', 'institute', 'program', 'quota', 'category']
    if 'gender' in df.columns:
        keys.append('gender')
    for key, g in df.groupby(keys, dropna=False):
        h = _final_years(g)
        years = sorted(h.year.astype(int).unique())
        if len(years) < min_train_years + 1:
            continue
        # Expanding-window backtest on the latest validation_years available.
        for val in years[-validation_years:]:
            train = h[h.year < val]
            if train.year.nunique() < min_train_years:
                continue
            x_years = train.year.to_numpy(dtype=float)
            y_train = train.last_rank.to_numpy(dtype=float)
            model = HistGradientBoostingRegressor(max_iter=250, l2_regularization=1.0, random_state=42)
            model.fit(pd.DataFrame({'year': x_years, 'year2': x_years ** 2}), y_train)
            pred = float(model.predict(pd.DataFrame({'year': [val], 'year2': [val ** 2]}))[0])
            actual = float(h.loc[h.year == val, 'last_rank'].iloc[0])
            rows.append({'actual_year': int(val), 'predicted': pred, 'actual': actual})
    if not rows:
        return None
    r = pd.DataFrame(rows)
    return {
        'rows': len(r),
        'mae': float(mean_absolute_error(r.actual, r.predicted)),
        'rmse': float(mean_squared_error(r.actual, r.predicted) ** 0.5),
        'r2': float(r2_score(r.actual, r.predicted)),
        'predictions': r
    }
