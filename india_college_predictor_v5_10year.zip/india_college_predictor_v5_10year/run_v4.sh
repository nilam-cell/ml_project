#!/usr/bin/env bash
set -e
python scripts/download_real_data.py
python scripts/build_dataset_v4.py
python scripts/train_v4.py
streamlit run app/streamlit_app.py
